#include<ulib.h>
  
int main (u64 arg1, u64 arg2, u64 arg3, u64 arg4, u64 arg5) {
    int a[8092];
    expand(4096,MM_WR);
    pmaps();
    char *ptr2 = mmap(NULL, 4096, PROT_READ, 0);
    if((long)ptr2< 0)
    {
        printf("MMAP FAILED\n");
        return -1;
    }
    pmaps();
    munmap(ptr2, 4096);
    return 0;
}

