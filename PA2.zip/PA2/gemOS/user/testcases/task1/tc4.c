#include<ulib.h>
  
int main (u64 arg1, u64 arg2, u64 arg3, u64 arg4, u64 arg5) {
    int a[3*4096];
    a[0] = 0;
    a[4096] = 4096;
    a[8192] = 8192;
    char *ptr1 = mmap(NULL, 4096, PROT_WRITE|PROT_READ, 0);
    if((long)ptr1< 0)
    {
        printf("MMAP FAILED\n");
        return -1;
    }
    pmaps();
    munmap(ptr1, 4096);
    char *ptr2 = mmap(NULL, 4096, PROT_READ, 0);
    if((long)ptr2< 0)
    {
        printf("MMAP FAILED\n");
        return -1;
    }
    pmaps();
    munmap(ptr2, 4096);
    return 0;

}

