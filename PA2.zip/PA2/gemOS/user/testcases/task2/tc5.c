#include<ulib.h>

int main(u64 arg1, u64 arg2, u64 arg3, u64 arg4, u64 arg5)
{
  int pages = 4096;
  char * lazy_alloc = mmap(NULL, pages*50, PROT_READ|PROT_WRITE, 0);
  if((long)lazy_alloc < 0)
  {
    printf("mmap failed \n");
    return 1;
  }
  pmap(0);

  for(int i = 0; i<25; i++)
  {
	  char* page_read = lazy_alloc + (i*pages);
	  char temp = page_read[0];
  }
  pmap(0);

  for(int i = 25; i<50; i++)
  {
	  char* page_read = lazy_alloc + (i*pages);
	  char temp = page_read[0];
  }
  pmap(0);

  return 0;
}


