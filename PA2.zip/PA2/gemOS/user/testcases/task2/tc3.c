#include<ulib.h>

int main(u64 arg1, u64 arg2, u64 arg3, u64 arg4, u64 arg5)
{
  int pages = 4096;
  char * mm1 = mmap(NULL, pages*6, PROT_READ, 0);
  if((long)mm1 < 0)
  {
    printf("mmap failed \n");
    return 1;
  }

  for(int i = 0; i < 6; i++){
        char temp;
        char* page_read = mm1 +(i*pages);
        temp = page_read[0];
  }
  pmap(0);
 
  for(int i = 0; i < 6; i++){
        char* page_write = mm1 +(i*pages);
        page_write[0] = 'A';
  }

  pmap(0);
  return 0;
}

